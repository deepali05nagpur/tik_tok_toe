### Calculator application built using Django
To run the server:

```python manage.py runserver```
